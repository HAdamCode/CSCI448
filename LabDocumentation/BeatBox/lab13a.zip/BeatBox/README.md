Fists Icon License
<a href="https://www.flaticon.com/free-icons/cooperative" title="cooperative icons">Cooperative icons created by Smashicons - Flaticon</a>